import javafx.application.Application;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.*;

public class Project1 extends Application {
    private static final String URL = "jdbc:mysql://localhost:3306/jku_eval_system";
    private static final String USER = "root";
    private static final String PASS = ""; 

    private Stage stage;
    private int currentUserId;
    private String currentFullName;

    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;
        showLogin();
    }

    private void showLogin() {
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #1a5276;");

        VBox card = new VBox(15);
        card.setMaxWidth(350); card.setPadding(new Insets(30));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 10;");
        card.setAlignment(Pos.CENTER);

        Label title = new Label("JKU EVALUATION SYSTEM");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField u = new TextField(); u.setPromptText("Username");
        PasswordField p = new PasswordField(); p.setPromptText("Password");
        Button loginBtn = new Button("SIGN IN");
        loginBtn.setPrefWidth(200);
        loginBtn.setStyle("-fx-background-color: #f1c40f; -fx-font-weight: bold;");

        Label statusLabel = new Label("Please Login");
        loginBtn.setOnAction(e -> handleLogin(u.getText(), p.getText(), statusLabel));

        card.getChildren().addAll(title, u, p, loginBtn, statusLabel);
        root.getChildren().add(card);
        stage.setScene(new Scene(root, 1000, 750));
        stage.show();
    }

    private void handleLogin(String user, String pass, Label status) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Users WHERE username=? AND password=?");
            ps.setString(1, user); ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                currentUserId = rs.getInt("user_id");
                currentFullName = rs.getString("full_name");
                String role = rs.getString("role");

                if (role.equalsIgnoreCase("admin")) showAdminUI();
                else if (role.equalsIgnoreCase("teacher")) showTeacherUI();
                else if (role.equalsIgnoreCase("student")) showStudentUI();
            } else {
                status.setText("Invalid Credentials");
                status.setStyle("-fx-text-fill: red;");
            }
        } catch (Exception ex) {
            status.setText("DB Connection Failed");
            ex.printStackTrace();
        }
    }

    // --- ADMIN: MANAGE USERS & VIEW STATS ---
    private void showAdminUI() {
        TabPane tabs = new TabPane();
        
        // TAB 1: USER MANAGEMENT
        VBox userMgt = new VBox(15);
        userMgt.setPadding(new Insets(20));
        
        TableView<User> table = new TableView<>();
        TableColumn<User, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        TableColumn<User, String> roleCol = new TableColumn<>("Role");
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));
        table.getColumns().addAll(nameCol, roleCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Add User Form
        HBox addForm = new HBox(10);
        TextField fName = new TextField(); fName.setPromptText("Full Name");
        TextField uName = new TextField(); uName.setPromptText("User");
        TextField pWord = new TextField(); pWord.setPromptText("Pass");
        ComboBox<String> roleCb = new ComboBox<>(FXCollections.observableArrayList("student", "teacher"));
        Button addBtn = new Button("Add");
        addBtn.setOnAction(e -> {
            addUser(fName.getText(), uName.getText(), pWord.getText(), roleCb.getValue());
            refreshTable(table);
        });
        
        Button delBtn = new Button("Delete Selected");
        delBtn.setOnAction(e -> {
            User s = table.getSelectionModel().getSelectedItem();
            if(s != null) { deleteUser(s.id); refreshTable(table); }
        });

        addForm.getChildren().addAll(fName, uName, pWord, roleCb, addBtn, delBtn);
        userMgt.getChildren().addAll(new Label("User Management"), table, addForm);
        refreshTable(table);

        // TAB 2: SYSTEM STATS
        VBox statsBox = new VBox(10);
        statsBox.setPadding(new Insets(20));
        TextArea statsArea = new TextArea();
        statsArea.setEditable(false);
        loadStats(statsArea, 0); // 0 = See all
        statsBox.getChildren().addAll(new Label("Overall University Performance"), statsArea);

        tabs.getTabs().addAll(new Tab("Users", userMgt), new Tab("Statistics", statsBox));
        
        // FIXED THE ERROR HERE:
        VBox layout = new VBox(createHeader("Admin Dashboard"), tabs);
        stage.setScene(new Scene(layout, 1000, 750));
    }

    // --- TEACHER: VIEW OWN PERFORMANCE ---
    private void showTeacherUI() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        TextArea statsArea = new TextArea();
        statsArea.setEditable(false);
        loadStats(statsArea, currentUserId);
        root.getChildren().addAll(createHeader("Teacher: " + currentFullName), new Label("My Performance Data:"), statsArea);
        stage.setScene(new Scene(root, 1000, 750));
    }

    // --- STUDENT: SUBMIT EVALUATION ---
    private void showStudentUI() {
        VBox root = new VBox();
        ScrollPane scroll = new ScrollPane();
        VBox content = new VBox(20);
        content.setPadding(new Insets(30));
        content.setAlignment(Pos.TOP_CENTER);

        ComboBox<String> tBox = new ComboBox<>();
        tBox.setPromptText("Select Lecturer");
        loadTeachersIntoBox(tBox);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10);
        grid.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-background-radius: 10;");
        
        String[] headers = {"Criteria", "Exc (5)", "V.Gd (4)", "Gd (3)", "Avg (2)", "Poor (1)"};
        for(int i=0; i<headers.length; i++) grid.add(new Label(headers[i]), i, 0);

        String[] qs = {"Delivery", "Syllabus", "Availability", "Punctuality", "CATs", "Interaction"};
        ToggleGroup[] groups = new ToggleGroup[6];
        for(int i=0; i<6; i++) {
            grid.add(new Label(qs[i]), 0, i+1);
            groups[i] = new ToggleGroup();
            for(int j=1; j<=5; j++) {
                RadioButton rb = new RadioButton();
                rb.setToggleGroup(groups[i]);
                rb.setUserData(6-j); 
                grid.add(rb, j, i+1);
            }
        }

        TextArea comm = new TextArea(); comm.setPromptText("Enter comments here...");
        Button sub = new Button("SUBMIT EVALUATION");
        sub.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;");
        sub.setOnAction(e -> saveEval(tBox.getValue(), groups, comm.getText()));

        content.getChildren().addAll(new Label("JKU STUDENT EVALUATION FORM"), tBox, grid, comm, sub);
        scroll.setContent(content);
        root.getChildren().addAll(createHeader("Student: " + currentFullName), scroll);
        stage.setScene(new Scene(root, 1000, 750));
    }

    // --- DATABASE HELPERS ---
    private void loadStats(TextArea area, int tid) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            String sql = "SELECT q1,q2,q3,q4,q5,q6 FROM Evaluations";
            if(tid > 0) sql += " WHERE teacher_id = " + tid;
            ResultSet rs = conn.createStatement().executeQuery(sql);
            int[] c = new int[6];
            while(rs.next()) {
                for(int i=1; i<=6; i++) { int v = rs.getInt(i); if(v>=1 && v<=5) c[v]++; }
            }
            area.setText("Excellent (5): " + c[5] + "\nVery Good (4): " + c[4] + 
                         "\nGood (3): " + c[3] + "\nAverage (2): " + c[2] + "\nPoor (1): " + c[1]);
        } catch (Exception e) {}
    }

    private void loadTeachersIntoBox(ComboBox<String> cb) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT full_name FROM Users WHERE role='teacher'");
            while(rs.next()) cb.getItems().add(rs.getString("full_name"));
        } catch (Exception e) {}
    }

    private void addUser(String f, String u, String p, String r) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Users (full_name, username, password, role) VALUES (?,?,?,?)");
            ps.setString(1, f); ps.setString(2, u); ps.setString(3, p); ps.setString(4, r);
            ps.executeUpdate();
        } catch (Exception e) {}
    }

    private void deleteUser(int id) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Users WHERE user_id=?");
            ps.setInt(1, id); ps.executeUpdate();
        } catch (Exception e) {}
    }

    private void refreshTable(TableView<User> t) {
        ObservableList<User> l = FXCollections.observableArrayList();
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM Users WHERE role != 'admin'");
            while(rs.next()) l.add(new User(rs.getInt("user_id"), rs.getString("full_name"), rs.getString("role")));
        } catch (Exception e) {}
        t.setItems(l);
    }

    private void saveEval(String tName, ToggleGroup[] gs, String c) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement psT = conn.prepareStatement("SELECT user_id FROM Users WHERE full_name=?");
            psT.setString(1, tName);
            ResultSet rsT = psT.executeQuery();
            if(rsT.next()) {
                PreparedStatement ps = conn.prepareStatement("INSERT INTO Evaluations (student_id, teacher_id, q1,q2,q3,q4,q5,q6, comments) VALUES (?,?,?,?,?,?,?,?,?)");
                ps.setInt(1, currentUserId); ps.setInt(2, rsT.getInt("user_id"));
                for(int i=0; i<6; i++) ps.setInt(i+3, gs[i].getSelectedToggle() != null ? (int)gs[i].getSelectedToggle().getUserData() : 0);
                ps.setString(9, c); ps.executeUpdate();
                new Alert(Alert.AlertType.INFORMATION, "Submitted!").show();
                showLogin();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private HBox createHeader(String name) {
        HBox h = new HBox(15); h.setPadding(new Insets(15)); h.setStyle("-fx-background-color: #1a5276;");
        Label l = new Label(name); l.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        Region s = new Region(); HBox.setHgrow(s, Priority.ALWAYS);
        Button logout = new Button("Logout"); logout.setOnAction(e -> showLogin());
        h.getChildren().addAll(l, s, logout);
        return h;
    }

    public static class User {
        public int id; public String fullName, role;
        public User(int id, String f, String r) { this.id = id; this.fullName = f; this.role = r; }
        public String getFullName() { return fullName; }
        public String getRole() { return role; }
    }

    public static void main(String[] args) { launch(args); }
}